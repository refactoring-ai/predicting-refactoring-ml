public class Cat extends Animal {


    @Override
    public void sound(String noiseInfo) {
        System.out.println("Miau " + noiseInfo);
    }


}