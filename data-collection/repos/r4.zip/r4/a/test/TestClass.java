import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;


class TestClass {

    @Test
    void addition() {
        assertEquals(3, 3);
    }

}