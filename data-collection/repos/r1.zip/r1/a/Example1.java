package a;

class Example1 {

	public void m1() {
		int a = 0;
		int b = a + 5;

		b = b * 2;

		System.out.println(b);

	}

}

